define([], function() {
  return {
    "Command1": "Command 1"
    //"Command2": "Command 2"
  }
});