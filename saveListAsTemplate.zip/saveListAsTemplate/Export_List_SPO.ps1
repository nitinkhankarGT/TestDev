﻿Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.dll" 
Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.Runtime.dll"


$UserName = "nitin@demoperform.onmicrosoft.com"
$Password = "aE7u7kva@1"
$creds = New-Object System.Management.Automation.PsCredential($UserName, (ConvertTo-SecureString $Password -AsPlainText -Force))

$FilePath = $PSScriptRoot + "\inputSites.csv"
$csv = Import-Csv $FilePath

$FileLocation = $PSScriptRoot + "\Exception.csv" 
$output = $PSScriptRoot + "\Output.csv"
write-output "SiteUrl,List,User_EMail,Message" | Out-File -FilePath $output -Append -Encoding ascii 
$Added= "List Added"       



foreach ($row in $csv)
{
    try
    {
        $SiteURL = $row.siteurl
        $listName=$row.listName
        $templateName = $row.templateName     

        Connect-PnPOnline -Url $SiteURL -UseWebLogin
        #sharepoint online powershell to add list
	try
	{

       
        Get-PnPProvisioningTemplate -Handlers Lists -ListsToExtract $listName -Out ("{0}.xml" -f $templateName)
        Add-PnPDataRowsToProvisioningTemplate -path ("{0}.xml" -f $templateName) -List $listName -Query '<view></view>'
    

		if($check.listName)
		{
			write-host $row.listName " : User Found!!"
			write-output "$($SiteURL),$($listName),$($templateName),$("List Found and Added")" | Out-File -FilePath $output -Append -Encoding ascii  
		}
		else
		{
			write-host $row.listName " : User Not Found!!"
			write-output "$($SiteURL),$($listName),$($templateName),$("List Not Found and Added")" | Out-File -FilePath $output -Append -Encoding ascii  
		}
		
	}
	catch
	{
		Write-Host "List not added"
		write-output "$($SiteURL),$($listName),$($templateName),$_.Exception.Message" | Out-File -FilePath $output -Append -Encoding ascii  
	}
        Disconnect-PnPOnline
    }
    catch
    {    
        write-output "$($row.siteurl),$_.Exception.Message" | Out-File -FilePath $FileLocation -Append -Encoding ascii  
        Disconnect-PnPOnline      
    }
Write-Host "Done for " $row.siteurl

}

