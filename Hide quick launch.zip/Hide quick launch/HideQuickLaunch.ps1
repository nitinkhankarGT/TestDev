﻿Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.dll" 
Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.Runtime.dll"


$UserName = "nitin@demoperform.onmicrosoft.com"
$Password = "aE7u7kva@1"
$creds = New-Object System.Management.Automation.PsCredential($UserName, (ConvertTo-SecureString $Password -AsPlainText -Force))

$FilePath = $PSScriptRoot + "\inputSiteCollection.csv"
$csv = Import-Csv $FilePath

$FileLocation = $PSScriptRoot + "\Exception.csv" 
$output = $PSScriptRoot + "\Output.csv"
write-output "SiteUrl,List,User_EMail,Message" | Out-File -FilePath $output -Append -Encoding ascii 
$Added= "List Added"       



foreach ($row in $csv)
{
    try
    {
        $SiteURL = $row.siteurl
        $Page=$row.page
        $PageID = $row.pageid

        Connect-PnPOnline -Url $SiteURL -UseWebLogin
        #sharepoint online powershell to add list
	try
	{
       #Get the Web
            $Web = Get-PnPWeb
 
            #Disable Quick Launch
            $web.QuickLaunchEnabled = $False
            $web.Update()
            Invoke-PnPQuery
  
    	Write-Host "Quick launch has been Removed"
	}
	catch
	{
		Write-Host "Page not added"
		 
	}
        Disconnect-PnPOnline
    }
    catch
    {    
        write-output "$($row.siteurl),$_.Exception.Message" | Out-File -FilePath $FileLocation -Append -Encoding ascii  
        Disconnect-PnPOnline      
    }
Write-Host "Done for " $row.siteurl

}

