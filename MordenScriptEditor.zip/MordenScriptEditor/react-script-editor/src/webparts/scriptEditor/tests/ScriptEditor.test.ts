/// <reference types="mocha" />

import { assert } from 'chai';

describe('ScriptEditorWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
