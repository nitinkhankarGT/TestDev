/* tslint:disable */
require("./ScriptEditor.module.css");
const styles = {

};

export default styles;
/* tslint:enable */