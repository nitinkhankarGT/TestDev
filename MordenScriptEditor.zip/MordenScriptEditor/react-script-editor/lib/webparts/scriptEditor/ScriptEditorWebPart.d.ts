import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { IScriptEditorWebPartProps } from './IScriptEditorWebPartProps';
export default class ScriptEditorWebPart extends BaseClientSideWebPart<IScriptEditorWebPartProps> {
    _propertyPaneHelper: any;
    private _unqiueId;
    constructor();
    scriptUpdate(_property: string, _oldVal: string, newVal: string): void;
    render(): void;
    private renderEditor;
    protected readonly dataVersion: Version;
    protected loadPropertyPaneResources(): Promise<void>;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
    private evalScript;
    private nodeName;
    private executeScript;
}
//# sourceMappingURL=ScriptEditorWebPart.d.ts.map