export interface IScriptEditorWebPartProps {
    script: string;
    title: string;
    removePadding: boolean;
    spPageContextInfo: boolean;
    teamsContext: boolean;
}
//# sourceMappingURL=IScriptEditorWebPartProps.d.ts.map