import * as React from 'react';
import { IScriptEditorProps } from './IScriptEditorProps';
export default class ScriptEditor extends React.Component<IScriptEditorProps, any> {
    constructor(props: IScriptEditorProps, state: any);
    componentDidMount(): void;
    private _showDialog;
    render(): React.ReactElement<IScriptEditorProps>;
}
//# sourceMappingURL=ScriptEditor.d.ts.map