declare const styles: {};
export default styles;
//# sourceMappingURL=ScriptEditor.module.scss.d.ts.map