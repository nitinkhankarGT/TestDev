﻿Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.dll" 
Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.Runtime.dll"


$UserName = "nitin@demoperform.onmicrosoft.com"
$Password = "aE7u7kva@1"
$creds = New-Object System.Management.Automation.PsCredential($UserName, (ConvertTo-SecureString $Password -AsPlainText -Force))

$FilePath = $PSScriptRoot + "\inputSiteCollection.csv"
$csv = Import-Csv $FilePath

$FileLocation = $PSScriptRoot + "\Exception.csv" 
$output = $PSScriptRoot + "\Output.csv"
write-output "SiteUrl,List,User_EMail,Message" | Out-File -FilePath $output -Append -Encoding ascii 
$Added= "List Added"       



foreach ($row in $csv)
{
    try
    {
        $SiteURL = $row.siteurl
        $List=$row.list
        $column1 = $row.column1
        $column2 =$row.column2
        $column3 =$row.column3

        Connect-PnPOnline -Url $SiteURL -UseWebLogin
        #sharepoint online powershell to add list
        $url=$SiteURL 
         $listName=$List
         $currentTime= $(get-date).ToString("yyyyMMddHHmmss")  
         $logFilePath=".\log-"+$currentTime+".docx"  
         # Fields that has to be retrieved  
         $Global:selectProperties=@($column1,$column2,$column3);  
	try
	{
     

    ## Start the Transcript  
    Start-Transcript -Path $logFilePath     
    ## Call the Function  
    ExportList  
    ## Export List to CSV ##  
        function ExportList  
        {  
            try  
            {  
                # Get all list items using PnP cmdlet  
                $listItems=(Get-PnPListItem -List $listName -Fields $Global:selectProperties).FieldValues  
                $outputFilePath="C:\Users\nkhanaka\OneDrive - Capgemini\ZNA\ZNA-Development-Phase\Scripts\ExportList to Excel\results-"+$currentTime+".csv"  
  
                $hashTable=@()  
 
                # Loop through the list items  
                foreach($listItem in $listItems)  
                {  
                    $obj=New-Object PSObject              
                    $listItem.GetEnumerator() | Where-Object { $_.Key -in $Global:selectProperties }| ForEach-Object{ $obj | Add-Member Noteproperty $_.Key $_.Value}  
                    $hashTable+=$obj;  
                    $obj=$null;  
                }  
  
                $hashtable | export-csv $outputFilePath -NoTypeInformation  
             }  
             catch [Exception]  
             {  
                $ErrorMessage = $_.Exception.Message         
                Write-Host "Error: $ErrorMessage" -ForegroundColor Red          
             }  
        }  
	}
	catch
	{
		Write-Host "Page not added"
		 
	}
        Disconnect-PnPOnline
    }
    catch
    {    
        write-output "$($row.siteurl),$_.Exception.Message" | Out-File -FilePath $FileLocation -Append -Encoding ascii  
        Disconnect-PnPOnline      
    }
Write-Host "Done for " $row.siteurl

}

