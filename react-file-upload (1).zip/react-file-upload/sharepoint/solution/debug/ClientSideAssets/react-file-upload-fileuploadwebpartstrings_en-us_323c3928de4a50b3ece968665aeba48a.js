define([], function() {
  return {
    "PropertyPaneDescription": "File Uploader WebPart",
    "BasicGroupName": "Look and feel"
  }
});