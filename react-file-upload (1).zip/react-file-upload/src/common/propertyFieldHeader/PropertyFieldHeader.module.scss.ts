/* tslint:disable */
require('./PropertyFieldHeader.module.css');
const styles = {
  headerBar: 'headerBar_a7084a19',
  header: 'header_a7084a19',
  info: 'info_a7084a19',
  headerCallout: 'headerCallout_a7084a19',
};

export default styles;
/* tslint:enable */