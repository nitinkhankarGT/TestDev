declare interface IFileUploadWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FileUploadWebPartStrings' {
  const strings: IFileUploadWebPartStrings;
  export = strings;
}
