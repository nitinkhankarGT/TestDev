/* tslint:disable */
require('./FileUpload.module.css');
const styles = {
  fileUpload: 'fileUpload_e07208ed',
  container: 'container_e07208ed',
  row: 'row_e07208ed',
  column: 'column_e07208ed',
  'ms-Grid': 'ms-Grid_e07208ed',
  title: 'title_e07208ed',
  subTitle: 'subTitle_e07208ed',
  description: 'description_e07208ed',
  button: 'button_e07208ed',
  label: 'label_e07208ed',
};

export default styles;
/* tslint:enable */