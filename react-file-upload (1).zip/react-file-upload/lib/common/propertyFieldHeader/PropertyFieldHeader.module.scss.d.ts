declare const styles: {
    headerBar: string;
    header: string;
    info: string;
    headerCallout: string;
};
export default styles;
