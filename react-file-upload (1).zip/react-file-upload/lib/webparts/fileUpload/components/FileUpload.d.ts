/// <reference types="react" />
import * as React from 'react';
import { IFileUploadProps } from './IFileUploadProps';
export default class FileUpload extends React.Component<IFileUploadProps, {}> {
    constructor(props: IFileUploadProps);
    render(): React.ReactElement<IFileUploadProps>;
}
