﻿Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.dll" 
Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.Runtime.dll"


$UserName = "nitin@demoperform.onmicrosoft.com"
$Password = "demoperfform123@45"
$encPassWord = convertto-securestring -String $passWord -AsPlainText -Force
$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $userName, $encPassWord

$FilePath = $PSScriptRoot + "\inputSiteCollection.csv"
$csv = Import-Csv $FilePath

$FileLocation = $PSScriptRoot + "\Exception.csv" 
$output = $PSScriptRoot + "\Output.csv"
write-output "SiteUrl,List,User_EMail,Message" | Out-File -FilePath $output -Append -Encoding ascii 
$Added= "List Added"       

#$TenantAdminURL = "https://crescent-admin.sharepoint.com"
#$SiteURL = "https://crescent.sharepoint.com/sites/Dev"

foreach ($row in $csv)
{
    try
    {
        $SiteURL = $row.siteurl
      
        #Connect-PnPOnline -Url $SiteURL -UseWebLogin
        Connect-PnPOnline -Url "https://demoperform1-admin.sharepoint.com" -UseWebLogin
       
	try
	{

      #######################The below command will Enable site collection app catalog on a modern team site in SharePoint Online###########################
        #Enable site collection app catalog
        Add-PnPSiteCollectionAppCatalog -Site $SiteURL


#Read more: https://www.sharepointdiary.com/2019/08/sharepoint-online-enable-site-collection-app-catalog-using-powershell.html#ixzz6gnQWdTn4
        Write-Host "The modern team site has been created successfully."    

		
		
	}
	catch
	{
		Write-Host "Site collection not added"
		write-output "$($Title),$($Alias),$_.Exception.Message" | Out-File -FilePath $output -Append -Encoding ascii  
	}
       
    }
    catch
    {    
        write-output "$($row.siteurl),$_.Exception.Message" | Out-File -FilePath $FileLocation -Append -Encoding ascii  
           
    }


}

