﻿Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.dll" 
Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.Runtime.dll"

$FilePath = $PSScriptRoot + "\inputSiteCollectionDownLoad.csv"
$csv = Import-Csv $FilePath

$FileLocation = $PSScriptRoot + "\Exception.csv" 
$output = $PSScriptRoot + "\Output.csv"
write-output "SiteUrl,List,User_EMail,Message" | Out-File -FilePath $output -Append -Encoding ascii 
$Added= "List Added"       

foreach ($row in $csv)
{
    try
    {
        $TenantSiteURL = $row.siteurl
        $SiteRelativeURL = $row.siteRelativeURL
        $LibraryName = $row.LibPath
        $DownloadPath ="C:\Users\nkhanaka\OneDrive - Capgemini\ZNA\ZNA-Development-Phase\Scripts\UploadBulkFilesToLibrary_SPO\DownloadedFiles"
 
        #Connect to PNP Online as Virtual Drive "SPO:\"
        Connect-PnPOnline -Url $TenantSiteURL -CreateDrive -UseWebLogin
 
        #Change the Path and navigate to the source site
        Set-Location -Path SPO:\$SiteRelativeURL
 
        #Download Document Library to Local Drive
        Copy-PnpItemProxy -Recurse -Force $LibraryName $DownloadPath
    	
        Write-Host "Document has been Downloaded"
	}
	
    catch
    {    
        write-output "$($row.siteurl),$_.Exception.Message" | Out-File -FilePath $FileLocation -Append -Encoding ascii  
        Disconnect-PnPOnline      
    }
    Write-Host "Done for " $row.siteurl

}