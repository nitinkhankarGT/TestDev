﻿Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.dll" 
Add-Type –Path "C:\Users\nkhanaka\Downloads\saveListAsTemplate\DLLs\Microsoft.SharePoint.Client.Runtime.dll"



$FilePath = $PSScriptRoot + "\inputSiteCollectionUploadFiles.csv"
$csv = Import-Csv $FilePath

$FileLocation = $PSScriptRoot + "\Exception.csv" 
$output = $PSScriptRoot + "\Output.csv"
write-output "SiteUrl,List,User_EMail,Message" | Out-File -FilePath $output -Append -Encoding ascii 
$Added= "List Added"       



foreach ($row in $csv)
{
    try
    {
        $SiteURL = $row.siteurl
        $FilesPath=$row.filesPath
        $SiteRelativePath = $row.LibPath

        Connect-PnPOnline -Url $SiteURL -UseWebLogin
        #sharepoint online powershell to add list
                #Get All Files from a Local Folder
                 $Files = Get-ChildItem -Path $FilesPath -Force -Recurse
	
       
       
 
        #Upload All files from the directory
        ForEach ($File in $Files)
        {
            Write-host "Uploading $($File.Directory)\$($File.Name)"
  
            #upload a file to sharepoint online using powershell - Upload File and Set Metadata
            Add-PnPFile -Path "$($File.Directory)\$($File.Name)" -Folder $SiteRelativePath -Values @{"Title" = $($File.Name)}
        }
  
    	Write-Host "Document has been Uploaded "
	}
	
    catch
    {    
        write-output "$($row.siteurl),$_.Exception.Message" | Out-File -FilePath $FileLocation -Append -Encoding ascii  
        Disconnect-PnPOnline      
    }
Write-Host "Done for " $row.siteurl

}

